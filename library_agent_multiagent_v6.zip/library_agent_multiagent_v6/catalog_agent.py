"""
Catalog Agent -- one of the library's three specialist agents.

Its only job is book lookups: given a title, report the book's category and
copy availability. It wraps the single check_catalog tool in a narrowly
scoped LangChain tool-calling agent, then exposes that whole agent to the
Supervisor (agent.py) as one callable tool: ask_catalog_agent.
"""

import os

from langchain.agents import create_agent
from langchain_core.tools import tool
from langchain_ollama import ChatOllama

from observability import TRACE_LOGGER
from tools import check_catalog

OLLAMA_MODEL = os.environ.get("LIBRARY_AGENT_MODEL", "llama3.1:8b")

CATALOG_AGENT_PROMPT = """You are the Catalog Agent for a university library.

Your only job is to look up books using the check_catalog tool and report
back their category and copy availability, clearly and briefly. If a title
is ambiguous or not found, say so plainly instead of guessing."""


def build_catalog_agent(model: str = None):
    """Returns a compiled, runnable LangGraph agent scoped to catalog lookups."""
    llm = ChatOllama(model=model or OLLAMA_MODEL, temperature=0, callbacks=[TRACE_LOGGER])
    return create_agent(llm, tools=[check_catalog], system_prompt=CATALOG_AGENT_PROMPT)


def _run_agent(agent, question: str) -> str:
    result = agent.invoke({"messages": [{"role": "user", "content": question}]})
    final_message = result["messages"][-1]
    return getattr(final_message, "content", str(final_message))


def make_catalog_agent_tool(model: str = None):
    """Builds the Catalog Agent once and wraps it as a @tool the Supervisor
    can call, passing a natural-language sub-question and getting back the
    Catalog Agent's natural-language answer."""
    catalog_agent = build_catalog_agent(model)

    @tool
    def ask_catalog_agent(question: str) -> str:
        """Delegate to the Catalog Agent. Ask about a book's category or
        availability, e.g. 'Is Clean Code available and what category is it?'"""
        return _run_agent(catalog_agent, question)

    return ask_catalog_agent
