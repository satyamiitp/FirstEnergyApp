"""
In-memory relational database for the library app, via SQLAlchemy.

This replaces the old approach in tools.py (loading catalog.json / rules.json
straight into Python dicts held in process memory) with a genuine SQLAlchemy
ORM + database layer -- the Python equivalent of using an H2 in-memory
database in a Java app: same idea (a real relational DB that lives only in
RAM for the life of the process, no file on disk, wiped on restart), just
SQLite as the engine instead of H2, since SQLite ships with Python itself.

Tables:
    books          -- one row per catalog entry (data/catalog.json)
    loan_rules     -- membership_type x category -> max_days (data/rules.json)
    max_books_held -- membership_type -> max simultaneous loans
    fine_rules     -- category -> fine_per_day, fine_cap
    renewal_rules  -- category -> renewals allowed (bool)
    app_config     -- scalar settings (max_active_reservations,
                      fine_block_threshold, rare_special_requires_approval)

data/catalog.json and data/rules.json remain the source of truth for seed
data -- they're just read once at startup and inserted into the database,
instead of being held directly as dicts. Everything downstream in tools.py
now queries the database instead of touching a dict.

IMPORTANT: SQLite's `:memory:` database is normally per-connection -- a new
connection gets a brand new, empty database. Since our app can issue queries
from multiple threads (FastAPI/uvicorn, LangGraph's tool-calling loop), we
use StaticPool so every session shares the exact same single connection,
keeping the same in-memory data visible everywhere for the life of the
process.
"""

import json
import os

from sqlalchemy import Boolean, Column, Float, Integer, String, create_engine
from sqlalchemy.orm import declarative_base, sessionmaker
from sqlalchemy.pool import StaticPool

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CATALOG_PATH = os.path.join(BASE_DIR, "data", "catalog.json")
RULES_PATH = os.path.join(BASE_DIR, "data", "rules.json")

engine = create_engine(
    "sqlite:///:memory:",
    connect_args={"check_same_thread": False},
    poolclass=StaticPool,
)
SessionLocal = sessionmaker(bind=engine)
Base = declarative_base()


class Book(Base):
    __tablename__ = "books"

    id = Column(Integer, primary_key=True)
    key = Column(String, unique=True, index=True)  # lowercase title, lookup key
    title = Column(String)
    category = Column(String)
    total_copies = Column(Integer)
    available_copies = Column(Integer)


class LoanRule(Base):
    __tablename__ = "loan_rules"

    id = Column(Integer, primary_key=True)
    membership_type = Column(String, index=True)
    category = Column(String, index=True)
    max_days = Column(Integer)


class MaxBooksHeld(Base):
    __tablename__ = "max_books_held"

    id = Column(Integer, primary_key=True)
    membership_type = Column(String, unique=True)
    max_books = Column(Integer)


class FineRule(Base):
    __tablename__ = "fine_rules"

    id = Column(Integer, primary_key=True)
    category = Column(String, unique=True)
    fine_per_day = Column(Float)
    fine_cap = Column(Float)


class RenewalRule(Base):
    __tablename__ = "renewal_rules"

    id = Column(Integer, primary_key=True)
    category = Column(String, unique=True)
    allowed = Column(Boolean)


class AppConfig(Base):
    __tablename__ = "app_config"

    key = Column(String, primary_key=True)
    value = Column(String)


def init_db() -> None:
    """Creates all tables and seeds them from data/catalog.json and
    data/rules.json. Safe to call more than once -- it no-ops if the books
    table is already populated (e.g. if this module gets imported twice)."""
    Base.metadata.create_all(engine)

    session = SessionLocal()
    try:
        if session.query(Book).first() is not None:
            return  # already seeded

        with open(CATALOG_PATH, "r", encoding="utf-8") as f:
            catalog = json.load(f)
        for key, entry in catalog.items():
            session.add(
                Book(
                    key=key,
                    title=entry["title"],
                    category=entry["category"],
                    total_copies=entry["total_copies"],
                    available_copies=entry["available_copies"],
                )
            )

        with open(RULES_PATH, "r", encoding="utf-8") as f:
            rules = json.load(f)

        for membership_type, categories in rules["max_loan_days"].items():
            for category, max_days in categories.items():
                session.add(
                    LoanRule(
                        membership_type=membership_type,
                        category=category,
                        max_days=max_days,
                    )
                )

        for membership_type, max_books in rules["max_books_held"].items():
            session.add(MaxBooksHeld(membership_type=membership_type, max_books=max_books))

        for category, fine_per_day in rules["fines_per_day"].items():
            fine_cap = rules["fine_cap_per_book"].get(category)
            session.add(FineRule(category=category, fine_per_day=fine_per_day, fine_cap=fine_cap))

        for category, allowed in rules["renewals_allowed"].items():
            session.add(RenewalRule(category=category, allowed=allowed))

        session.add(AppConfig(key="max_active_reservations", value=str(rules["max_active_reservations"])))
        session.add(AppConfig(key="fine_block_threshold", value=str(rules["fine_block_threshold"])))
        session.add(
            AppConfig(
                key="rare_special_requires_approval",
                value=str(rules.get("rare_special_requires_approval", False)),
            )
        )

        session.commit()
    finally:
        session.close()


def get_book(book_title: str):
    """Returns a dict {title, category, total_copies, available_copies} for
    a case-insensitive title match, or None if not found."""
    session = SessionLocal()
    try:
        key = book_title.strip().lower()
        book = session.query(Book).filter(Book.key == key).first()
        if not book:
            return None
        return {
            "title": book.title,
            "category": book.category,
            "total_copies": book.total_copies,
            "available_copies": book.available_copies,
        }
    finally:
        session.close()


def get_valid_membership_types():
    """Returns the set of membership_type values that exist in loan_rules."""
    session = SessionLocal()
    try:
        rows = session.query(LoanRule.membership_type).distinct().all()
        return {r[0] for r in rows}
    finally:
        session.close()


def get_loan_rule(membership_type: str, category: str):
    """Returns max_days (int) for this membership_type/category, or None if
    no such row exists (i.e. unknown category)."""
    session = SessionLocal()
    try:
        rule = (
            session.query(LoanRule)
            .filter(LoanRule.membership_type == membership_type, LoanRule.category == category)
            .first()
        )
        return rule.max_days if rule else None
    finally:
        session.close()


def rare_special_requires_approval() -> bool:
    session = SessionLocal()
    try:
        cfg = session.query(AppConfig).filter(AppConfig.key == "rare_special_requires_approval").first()
        return cfg is not None and cfg.value == "True"
    finally:
        session.close()


def get_rules_dict() -> dict:
    """Reconstructs the same nested-dict shape as the original rules.json,
    purely by querying the database. This exists only so agent.py's
    Supervisor system prompt (which does json.dumps(RULES, indent=2) to give
    the LLM context) doesn't need to change at all -- it still gets a plain
    dict, just sourced from the DB instead of directly from the JSON file."""
    session = SessionLocal()
    try:
        max_loan_days: dict = {}
        for r in session.query(LoanRule).all():
            max_loan_days.setdefault(r.membership_type, {})[r.category] = r.max_days

        max_books_held = {m.membership_type: m.max_books for m in session.query(MaxBooksHeld).all()}

        fines_per_day = {}
        fine_cap_per_book = {}
        for f in session.query(FineRule).all():
            fines_per_day[f.category] = f.fine_per_day
            fine_cap_per_book[f.category] = f.fine_cap

        renewals_allowed = {r.category: r.allowed for r in session.query(RenewalRule).all()}

        cfg = {c.key: c.value for c in session.query(AppConfig).all()}

        return {
            "max_loan_days": max_loan_days,
            "max_books_held": max_books_held,
            "max_active_reservations": int(cfg.get("max_active_reservations", 0)),
            "fines_per_day": fines_per_day,
            "fine_cap_per_book": fine_cap_per_book,
            "fine_block_threshold": int(cfg.get("fine_block_threshold", 0)),
            "renewals_allowed": renewals_allowed,
            "rare_special_requires_approval": cfg.get("rare_special_requires_approval") == "True",
        }
    finally:
        session.close()
