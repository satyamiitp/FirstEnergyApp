"""
Builds the Library Management multi-agent system.

Architecture -- Supervisor + specialists (agents-as-tools pattern):

    Member query
         |
         v
    Supervisor Agent  (this module's build_agent())
         |-- delegates to --> Catalog Agent  --> check_catalog tool
         |-- delegates to --> Rules Agent    --> check_loan_rule tool
         '-- delegates to --> Policy Agent   --> retrieve_policy tool (RAG)
         |
         v
    One synthesized final answer to the member

Each specialist agent lives in its own file:
    catalog_agent.py  -> Catalog Agent  (check_catalog)
    rules_agent.py    -> Rules Agent    (check_loan_rule)
    policy_agent.py   -> Policy Agent   (retrieve_policy, RAG)

Each is its own create_agent() tool-calling loop scoped to a single job, and
each file exposes a make_*_agent_tool() function that builds the agent and
wraps it as a plain tool (ask_catalog_agent / ask_rules_agent /
ask_policy_agent) -- so from the Supervisor's point of view, "delegate to a
specialist" looks just like "call a tool", but each call is itself a full
LLM reasoning loop.

Rules are still SYSTEM INPUT: data/rules.json is loaded and summarized into
the Supervisor's system prompt for context, but the exact approve/deny/cap
decision is only ever produced by the Rules Agent's check_loan_rule tool
call -- no agent in the system is trusted to compute limits from memory.

Uses LangChain's current (v1) agent API: create_agent, which builds a
LangGraph tool-calling loop under the hood, for every agent in the system
(Supervisor and all three specialists).

Three additions on top of the base multi-agent design, all only at the
Supervisor level (the specialists stay simple, single-shot delegation
targets):

  - Observability: every ChatOllama in the app (this file and all three
    specialist files) is given the shared TRACE_LOGGER callback, which
    prints a readable trace of every LLM call and tool call to the
    console. LangSmith tracing is also picked up automatically if the
    right environment variables are set -- see observability.py.
  - Conversation memory: a LangGraph checkpointer (MemorySaver) is
    attached to the Supervisor, so the same conversation ("thread_id")
    can span multiple .invoke()/.ainvoke() calls and the Supervisor
    remembers earlier turns. Callers must pass
    config={"configurable": {"thread_id": "..."}} -- see main.py and
    api.py for how each keeps track of a thread_id.
  - Structured output: response_format=LoanResponse (schemas.py) makes
    the Supervisor also return a typed, parsed object in
    result["structured_response"], alongside the normal plain-text
    answer in result["messages"][-1]. Since main.py and api.py now need
    to supply a thread_id and can read structured_response, they are no
    longer completely decoupled from these Supervisor-level choices --
    but the specialist agents underneath remain untouched.
"""

import json
import os

from langchain.agents import create_agent
from langchain_ollama import ChatOllama
from langgraph.checkpoint.memory import MemorySaver

from observability import TRACE_LOGGER
from schemas import LoanResponse
from tools import RULES
from catalog_agent import make_catalog_agent_tool
from rules_agent import make_rules_agent_tool
from policy_agent import make_policy_agent_tool

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

OLLAMA_MODEL = os.environ.get("LIBRARY_AGENT_MODEL", "llama3.1:8b")

SUPERVISOR_SYSTEM_PROMPT = f"""You are the Supervisor of a multi-agent library
management system for a university library. You do not look anything up
yourself -- you delegate to three specialist agents, each an expert in one
narrow area:

  - ask_catalog_agent: book category & availability lookups
  - ask_rules_agent:   authoritative loan-rule approve/deny/cap decisions
  - ask_policy_agent:  fines, renewals, reservations, membership policy wording

A condensed copy of the system rules is given here for your own context (the
Rules Agent is still the sole source of truth for any specific decision):
{json.dumps(RULES, indent=2)}

Your workflow for a loan request should generally be:
1. Identify the member's membership_type (Student/Faculty/Guest), the book
   title, and the requested number of days. Ask the member a clarifying
   question ONLY if one of these is genuinely missing or ambiguous.
2. Delegate to ask_catalog_agent to find the book's category and availability.
3. Delegate to ask_rules_agent with the membership_type, category, and
   requested days to get the authoritative approve/deny/cap decision.
4. If the member's question touches on fines, renewals, reservations, or "why"
   a rule exists, delegate to ask_policy_agent to ground your explanation in
   the actual policy text.
5. Combine the specialists' answers into ONE clear final answer to the
   member: approved / capped / denied, due date logic (in days from today),
   any applicable fine rate if returned late, and next steps if the book is
   unavailable (offer a reservation).

Never override or contradict a decision reported by ask_rules_agent. Be
concise and practical, like a helpful librarian, not a legal document.
"""


def build_agent(model: str = None):
    """Returns a compiled, runnable LangGraph Supervisor agent that delegates
    to the Catalog/Rules/Policy specialist agents. Invoke it with:
        agent.invoke(
            {"messages": [{"role": "user", "content": user_text}]},
            config={"configurable": {"thread_id": "some-id"}},
        )
    A thread_id is required because this agent has a checkpointer attached
    (conversation memory) -- reuse the same thread_id across calls to
    continue one conversation, or use a fresh one to start a new one.

    The result dict has both:
        result["messages"][-1]        -- normal plain-text final answer
        result["structured_response"] -- a parsed LoanResponse (schemas.py)
    """
    llm = ChatOllama(model=model or OLLAMA_MODEL, temperature=0, callbacks=[TRACE_LOGGER])
    specialist_tools = [
        make_catalog_agent_tool(model),
        make_rules_agent_tool(model),
        make_policy_agent_tool(model),
    ]
    return create_agent(
        llm,
        tools=specialist_tools,
        system_prompt=SUPERVISOR_SYSTEM_PROMPT,
        response_format=LoanResponse,
        checkpointer=MemorySaver(),
    )
