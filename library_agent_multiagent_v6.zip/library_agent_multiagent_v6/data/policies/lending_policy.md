# Book Lending Policy

## Loan Periods by Membership Type

Students may borrow General Collection books for up to 14 days per loan. Faculty
members may borrow General Collection books for up to 30 days per loan. Guest
members may borrow General Collection books for up to 7 days per loan.

Reference Collection books (marked "Reference Only") do not circulate and cannot
be borrowed for any period; they may only be used inside the library.

Reserve Collection books (course reserves placed by instructors) may be borrowed
by any member for a maximum of 3 days, to ensure availability for the whole class.

Rare and Special Collection items may be borrowed only by Faculty members, for a
maximum of 5 days, and require Head Librarian approval regardless of duration.

## Requesting a Shorter or Longer Loan

A member may request a loan period shorter than the maximum allowed for their
membership type and the book's category; shorter requests are always granted if
the book is available. A member may not request a loan period longer than the
maximum allowed for their membership type and book category — such requests must
be either rejected or capped at the maximum allowed period, and the member should
be informed of the applicable maximum.

## Multiple Copies and Availability

If a requested book has zero available copies, the request cannot be fulfilled
immediately. The member should be offered a reservation (hold) instead, per the
Reservation Policy.
