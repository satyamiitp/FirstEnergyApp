# Membership Policy

There are three membership types: Student, Faculty, and Guest.

- Students may hold up to 5 borrowed books at once.
- Faculty may hold up to 15 borrowed books at once.
- Guests may hold up to 2 borrowed books at once.

Membership type determines both the maximum loan period allowed (see Lending
Policy) and the maximum number of books a member may hold simultaneously. New
members are onboarded as Guests until their Student or Faculty status is
verified by the front desk, after which their account is upgraded.
