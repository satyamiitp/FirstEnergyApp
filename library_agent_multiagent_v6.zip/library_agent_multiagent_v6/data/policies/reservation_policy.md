# Reservation (Hold) Policy

If a book has no available copies, a member may place a reservation. Reservations
are served in first-come, first-served order. When a reserved copy becomes
available, the member has 48 hours to collect it before it passes to the next
person in the queue.

A member may hold a maximum of 3 active reservations at any time. Reference
Collection and Rare/Special Collection items generally cannot be reserved, since
they do not circulate or require special approval.

## Renewals

A loan may be renewed once, for the same duration as the original loan period,
provided no other member has an active reservation on that book and the member
has no unpaid fines over $15. Reserve Collection books cannot be renewed under
any circumstances, since they are shared course materials with high demand.
