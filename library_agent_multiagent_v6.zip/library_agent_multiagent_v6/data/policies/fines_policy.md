# Overdue Fines Policy

Overdue fines accrue once a book is not returned by its due date, starting from
the day after the due date.

- General Collection books: fine of $0.25 per day overdue, capped at $10 per book.
- Reserve Collection books: fine of $1.00 per day overdue, capped at $15 per book,
  because these are course materials shared by many students.
- Rare and Special Collection items: fine of $5.00 per day overdue, capped at $100
  per item, plus possible loss of borrowing privileges for repeat offenses.

A member with any unpaid fine over $15 will have new loan requests automatically
declined until the balance is settled.

Lost or damaged books are charged at replacement cost plus a $10 processing fee,
in addition to any accrued overdue fines.
