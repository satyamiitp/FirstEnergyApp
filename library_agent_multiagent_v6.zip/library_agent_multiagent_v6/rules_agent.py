"""
Rules Agent -- one of the library's three specialist agents.

Its only job is enforcing data/rules.json exactly. It wraps the single
check_loan_rule tool in a narrowly scoped LangChain tool-calling agent, then
exposes that whole agent to the Supervisor (agent.py) as one callable tool:
ask_rules_agent.
"""

import os

from langchain.agents import create_agent
from langchain_core.tools import tool
from langchain_ollama import ChatOllama

from observability import TRACE_LOGGER
from tools import check_loan_rule

OLLAMA_MODEL = os.environ.get("LIBRARY_AGENT_MODEL", "llama3.1:8b")

RULES_AGENT_PROMPT = """You are the Rules/Compliance Agent for a university library.

Your only job is to call check_loan_rule with the membership_type, book
category, and requested days you are given, and report the exact result
(approved / capped / denied) plus any approval notes. Never override,
round, or recompute the numeric result yourself -- the tool is the sole
source of truth for loan-period limits."""


def build_rules_agent(model: str = None):
    """Returns a compiled, runnable LangGraph agent scoped to loan-rule checks."""
    llm = ChatOllama(model=model or OLLAMA_MODEL, temperature=0, callbacks=[TRACE_LOGGER])
    return create_agent(llm, tools=[check_loan_rule], system_prompt=RULES_AGENT_PROMPT)


def _run_agent(agent, question: str) -> str:
    result = agent.invoke({"messages": [{"role": "user", "content": question}]})
    final_message = result["messages"][-1]
    return getattr(final_message, "content", str(final_message))


def make_rules_agent_tool(model: str = None):
    """Builds the Rules Agent once and wraps it as a @tool the Supervisor can
    call, passing a natural-language sub-question and getting back the Rules
    Agent's natural-language answer."""
    rules_agent = build_rules_agent(model)

    @tool
    def ask_rules_agent(question: str) -> str:
        """Delegate to the Rules/Compliance Agent. Ask it to check a loan
        request, e.g. 'Can a Student borrow a General book for 5 days?'"""
        return _run_agent(rules_agent, question)

    return ask_rules_agent
