"""
Builds a local FAISS vector store from the policy documents in data/policies/.
This is the RAG index the agent's PolicyRetriever tool searches at query time.

Run once (or whenever policy docs change):
    python build_vectorstore.py
"""

import glob
import os

from langchain_community.vectorstores import FAISS
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_core.documents import Document

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
POLICY_DIR = os.path.join(BASE_DIR, "data", "policies")
INDEX_DIR = os.path.join(BASE_DIR, "data", "faiss_index")


def load_policy_documents():
    docs = []
    for path in sorted(glob.glob(os.path.join(POLICY_DIR, "*.md"))):
        with open(path, "r", encoding="utf-8") as f:
            text = f.read()
        docs.append(Document(page_content=text, metadata={"source": os.path.basename(path)}))
    return docs


def main():
    print(f"Loading policy documents from {POLICY_DIR} ...")
    raw_docs = load_policy_documents()
    print(f"  loaded {len(raw_docs)} document(s)")

    splitter = RecursiveCharacterTextSplitter(
        chunk_size=500,
        chunk_overlap=60,
        separators=["\n## ", "\n\n", "\n", " "],
    )
    chunks = splitter.split_documents(raw_docs)
    print(f"  split into {len(chunks)} chunks")

    print("Loading local embedding model (sentence-transformers/all-MiniLM-L6-v2) ...")
    embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")

    print("Building FAISS index ...")
    vectorstore = FAISS.from_documents(chunks, embeddings)
    vectorstore.save_local(INDEX_DIR)
    print(f"Saved FAISS index to {INDEX_DIR}")


if __name__ == "__main__":
    main()
