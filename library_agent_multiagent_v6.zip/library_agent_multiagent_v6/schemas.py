"""
Structured output schema for the Supervisor's final answer.

Passed to create_agent(..., response_format=LoanResponse) in agent.py.
LangChain handles turning this into a model-appropriate strategy under the
hood (for a tool-calling model like llama3.1 via Ollama, that's typically an
extra "extract structured data" tool call at the end of the conversation)
and returns the parsed result as result["structured_response"] alongside
the normal plain-text answer in result["messages"][-1].

Why this exists: the plain-text answer is fine for a human reading it in a
terminal or chat window, but a real client (a mobile app, a website) would
otherwise have to parse English sentences to know whether a loan was
approved, capped, or denied. This schema gives every caller of the API a
reliable, typed field to check instead.
"""

from typing import Literal, Optional

from pydantic import BaseModel, Field


class LoanResponse(BaseModel):
    """Structured summary of the Supervisor's decision for a member's request."""

    decision: Literal["approved", "capped", "denied", "not_applicable"] = Field(
        description=(
            "Outcome of the loan request. Use 'not_applicable' if the member's "
            "message wasn't a loan request at all (e.g. a general policy question)."
        )
    )
    book_title: Optional[str] = Field(
        default=None, description="Title of the book being discussed, if any."
    )
    approved_days: Optional[int] = Field(
        default=None,
        description="Number of days actually approved for the loan, if decision is 'approved' or 'capped'.",
    )
    due_date_note: Optional[str] = Field(
        default=None,
        description="Human-readable due date guidance, e.g. '5 days from today'.",
    )
    fine_note: Optional[str] = Field(
        default=None,
        description="Applicable fine information if the book is returned late, if relevant to this request.",
    )
    availability_note: Optional[str] = Field(
        default=None,
        description="Book availability info, e.g. copies currently available, or a reservation offer if unavailable.",
    )
    message: str = Field(
        description="A friendly, human-readable summary of the answer, written like a helpful librarian."
    )
