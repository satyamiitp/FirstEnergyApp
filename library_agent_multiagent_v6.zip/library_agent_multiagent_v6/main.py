"""
CLI entry point for the Library Management agent.

Usage:
    python main.py                     # interactive chat loop
    python main.py "I'm a student and I need Clean Code for 5 days"

The Supervisor now has conversation memory (a LangGraph checkpointer), so
every call in this file uses the same thread_id for the life of one CLI
session -- meaning follow-up questions like "okay, make it 10 days instead"
have access to what you asked before, within a single run of this script.

Console trace logging (observability.py) is on by default, so you'll see a
line for every LLM call and tool call as the Supervisor and specialists
work through your request.
"""

import sys
import uuid

from dotenv import load_dotenv

load_dotenv()

from agent import build_agent
from observability import langsmith_status


def run_once(agent, user_input: str, thread_id: str) -> None:
    config = {"configurable": {"thread_id": thread_id}}
    result = agent.invoke({"messages": [{"role": "user", "content": user_input}]}, config=config)

    structured = result.get("structured_response")
    if structured is not None:
        # With response_format set, the LAST message in result["messages"] is
        # actually a generic auto-generated acknowledgment (e.g. "Returning
        # structured response: ..."), not a friendly answer -- the real
        # human-readable text lives in structured_response.message instead.
        content = structured.message
    else:
        final_message = result["messages"][-1]
        content = getattr(final_message, "content", final_message)

    print("\nAgent:", content)

    if structured is not None:
        print("\nStructured:", structured.model_dump_json(indent=2))
    print()


def main():
    print("Loading agent (model + FAISS index)...")
    agent = build_agent()
    print(langsmith_status())
    print("Ready. (Ctrl+C to quit)\n")

    thread_id = str(uuid.uuid4())

    if len(sys.argv) > 1:
        run_once(agent, " ".join(sys.argv[1:]), thread_id)
        return

    while True:
        try:
            user_input = input("You: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye.")
            break
        if not user_input:
            continue
        if user_input.lower() in {"exit", "quit"}:
            break
        run_once(agent, user_input, thread_id)


if __name__ == "__main__":
    main()
