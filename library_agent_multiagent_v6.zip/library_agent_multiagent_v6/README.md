# Library Management Agent (LangChain + RAG + Ollama) — Multi-Agent Edition

A multi-agent library-loan assistant, built as a **Supervisor + specialists**
system:

```
Member query
     |
     v
Supervisor Agent  (agent.py)
     |-- delegates to --> Catalog Agent  --> check_catalog tool
     |-- delegates to --> Rules Agent    --> check_loan_rule tool
     '-- delegates to --> Policy Agent   --> retrieve_policy tool (RAG)
     |
     v
One synthesized final answer to the member
```

- **Catalog Agent**: looks up a book's category and copy availability (`check_catalog`).
- **Rules Agent**: deterministically enforces the loan rules via `check_loan_rule` — the model never computes limits itself.
- **Policy Agent**: RAG search over `data/policies/*.md` (embedded into a local FAISS index) to explain fines, renewals, reservations, membership wording.
- **Supervisor Agent**: the entry point. It doesn't call any low-level tool directly — it delegates to the three specialists above (each exposed to it as a tool: `ask_catalog_agent`, `ask_rules_agent`, `ask_policy_agent`) and combines their answers into one final response.

Each specialist is itself a full LangChain tool-calling agent (`create_agent`), just scoped to a single job — this is the "agents-as-tools" multi-agent pattern. From the Supervisor's perspective, delegating to a specialist looks like calling a tool; under the hood that call runs its own LLM reasoning loop. Each specialist lives in its own file.

**Data layer**: `check_catalog` and `check_loan_rule` no longer read `catalog.json`/`rules.json` into plain Python dicts. They query an in-memory SQLite database via SQLAlchemy (`db.py`) — the Python equivalent of using an H2 in-memory database in a Java app. `data/catalog.json` and `data/rules.json` are still the source of truth for seed data: `db.py` reads them once at startup and inserts the rows into tables (`books`, `loan_rules`, `max_books_held`, `fine_rules`, `renewal_rules`, `app_config`), then every lookup afterward is a real SQL query through the ORM. The database is in-memory only — it's rebuilt from the JSON files every time the process starts, nothing persists across restarts.

```
library_agent/
  data/
    policies/            # RAG source documents
    rules.json           # seed data for loan_rules / fine_rules / etc.
    catalog.json          # seed data for the books table
  db.py                   # SQLAlchemy models + in-memory SQLite DB + seeding
  observability.py         # console trace logger (LLM/tool calls) + LangSmith status
  schemas.py                # LoanResponse -- structured output schema for the Supervisor
  build_vectorstore.py    # builds the FAISS index (run once)
  tools.py                # raw tools: retrieve_policy, check_loan_rule, check_catalog
  catalog_agent.py         # Catalog Agent (multi-agent layer), wrapped as ask_catalog_agent tool
  rules_agent.py           # Rules Agent (multi-agent layer), wrapped as ask_rules_agent tool
  policy_agent.py          # Policy Agent (multi-agent layer), wrapped as ask_policy_agent tool
  agent.py                 # Supervisor / orchestrator agent (system prompt + delegation logic)
  main.py                  # CLI
  api.py                   # FastAPI wrapper (async, conversation memory, structured output)
```

## What's new on top of the base multi-agent design

Four additions, all at the Supervisor level (the three specialists stay simple, single-shot delegation targets -- only `agent.py`, `main.py`, and `api.py` changed):

- **Observability**: every `ChatOllama` in the app (Supervisor + all 3 specialists) is given a shared callback (`observability.py`'s `TRACE_LOGGER`) that prints a readable trace of every LLM call and tool call to the console as it happens -- which agent is calling the model, whether it asked for a tool or gave a final answer, and how long each step took. Zero setup, zero external service. If you also want a full web-based trace viewer, set `LANGSMITH_TRACING=true` and `LANGSMITH_API_KEY=...` in your environment (get a free key at smith.langchain.com) -- LangChain picks this up automatically, no code changes needed. `langsmith_status()` prints which mode is active at startup.
- **Conversation memory**: the Supervisor now has a LangGraph checkpointer (`MemorySaver`), so it can remember earlier turns within the same conversation ("thread"). `main.py` generates one `thread_id` per CLI session automatically. `api.py`'s `/ask` accepts an optional `thread_id` in the request; if you omit it, a new one is generated and returned in the response -- pass that same `thread_id` back on your next call to continue the conversation (e.g. asking "okay, make it 10 days instead" as a follow-up).
- **Structured output**: the Supervisor's `create_agent(..., response_format=LoanResponse)` (schema in `schemas.py`) means every answer also comes back as a typed, parsed object (`decision`, `book_title`, `approved_days`, `due_date_note`, `fine_note`, `availability_note`, `message`) in addition to the plain-text answer -- useful if a real client needs to check "was this approved?" without parsing English sentences. Note: when this is active, `result["messages"][-1]` becomes a generic auto-generated acknowledgment rather than the friendly answer -- both `main.py` and `api.py` already handle this correctly by preferring `structured_response.message` as the display text.
- **Async FastAPI**: `api.py`'s `/ask` and `/health` are `async def`, and `/ask` calls `await _agent.ainvoke(...)` instead of blocking `.invoke(...)`, so the server can keep handling other requests while one multi-agent chain (up to ~7 sequential LLM calls) is still running. Startup now uses FastAPI's modern `lifespan` context manager instead of the deprecated `@app.on_event("startup")`.

## 1. Install Ollama (runs the LLM locally on your Mac)

```bash
brew install ollama
brew services start ollama
```

(Or download the Mac app from ollama.com if you don't use Homebrew.)

## 2. Pull a model

For an M-series Mac, quick + tool-calling-capable options, easiest first:

| Model | Pull command | Size | Notes |
|---|---|---|---|
| **Llama 3.1 8B** (recommended) | `ollama pull llama3.1:8b` | ~4.7GB | Best balance of speed and reliable tool-calling for this project. Needs ~8GB+ RAM. |
| Llama 3.2 3B | `ollama pull llama3.2:3b` | ~2GB | Fastest to download/run, works on 8GB Macs, tool-calling is a bit less reliable. |
| Qwen 2.5 7B Instruct | `ollama pull qwen2.5:7b` | ~4.7GB | Also strong at tool calling, good alternative to Llama 3.1. |

Start with `llama3.1:8b`. If your Mac has 8GB RAM or less, use `llama3.2:3b` instead and set `LIBRARY_AGENT_MODEL=llama3.2:3b`.

The Supervisor and all three specialists share this one model by default (set via `LIBRARY_AGENT_MODEL`, same as before). Note the multi-agent version makes more LLM calls per query (1 supervisor turn + up to 3 specialist turns), so expect it to be slower than the single-agent version — that's the tradeoff for specialization.

## 3. Set up Python

**Requires Python 3.10 or newer.** This project uses LangChain 1.x's `create_agent` API, which does not install on Python 3.9 or older -- `pip install -r requirements.txt` will fail with "No matching distribution found for langchain" if your interpreter is too old. Check first:

```bash
python3 --version
```

If that's below 3.10, the most reliable fix is to use conda instead of `venv`, since it manages its own Python interpreter rather than depending on whichever `python3` happens to be first on your `PATH`:

```bash
conda create -n library_agent -c conda-forge python=3.12 -y
conda activate library_agent
```

(Using `-c conda-forge` here avoids Anaconda's default-channel Terms-of-Service prompt, which can otherwise make `conda create` silently fail to create the environment.)

If your system `python3` is already 3.10+, a plain venv works fine instead:

```bash
cd library_agent
python3 -m venv .venv
source .venv/bin/activate
```

Either way, once the environment is active:

```bash
pip install -r requirements.txt
```

## 4. Build the RAG index (one-time)

```bash
python build_vectorstore.py
```

## 5. Run it

```bash
python main.py
```

Or a one-shot query:

```bash
python main.py "I'm a student and I need Clean Code for 5 days"
```

To use a different pulled model:

```bash
LIBRARY_AGENT_MODEL=llama3.2:3b python main.py
```

## Serving over HTTP (Postman etc.)

```bash
uvicorn api:app --reload --port 8000
```

- `GET /health` -> liveness check
- `POST /ask` with `{"query": "..."}` -> `{"response": "...", "thread_id": "...", "structured": {...}}`

`thread_id` is optional in the request -- omit it for a fresh conversation (one gets generated and returned), or pass back a `thread_id` from a previous response to continue that same conversation. `structured` is the parsed `LoanResponse` object (see `schemas.py`) -- `null` only if structured extraction somehow failed.

Example:

```json
// Request
{"query": "I'm a student and I need Clean Code for 5 days"}

// Response
{
  "response": "You're approved to borrow Clean Code for 5 days...",
  "thread_id": "3f9a1c2e-...",
  "structured": {
    "decision": "approved",
    "book_title": "Clean Code",
    "approved_days": 5,
    "due_date_note": "5 days from today",
    "fine_note": null,
    "availability_note": "1 of 3 copies available",
    "message": "You're approved to borrow Clean Code for 5 days..."
  }
}
```

Follow-up in the same conversation:

```json
{"query": "okay, make it 10 days instead", "thread_id": "3f9a1c2e-..."}
```

## Example queries to try

- "I'm a student and I need Clean Code for 5 days"
- "As faculty, can I borrow the First Folio Facsimile for 10 days?"
- "I'm a guest, is Deep Learning available? If not what are my options?"
- "What happens if I return Introduction to Algorithms 3 days late as a student?"
- "Can I renew my copy of The Great Gatsby?"

## Extending it

- Move from the in-memory SQLite database to a real production database (Postgres, MySQL, etc.) by changing the single `create_engine("sqlite:///:memory:", ...)` line in `db.py` to a real connection URL (e.g. `postgresql://user:pass@host/dbname`) and dropping the `StaticPool` workaround (that's only needed for SQLite's in-memory quirk). Nothing in `tools.py` or the agents needs to change, since they only call `db.py`'s query functions.
- Add a `create_reservation` / `renew_loan` tool (and a `Loan`/`Reservation` table in `db.py`) + a corresponding new specialist agent file (e.g. `reservation_agent.py`), then register its tool in `agent.py`.
- Give a specialist its own model via `build_catalog_agent(model="llama3.2:3b")` etc. in that specialist's own file if you want a lighter/faster model for simple lookups and a stronger one only for the Supervisor.
- Swap `ChatOllama` in `agent.py` / `catalog_agent.py` / `rules_agent.py` / `policy_agent.py` for `ChatAnthropic` if you'd rather call the Claude API instead of running locally.
