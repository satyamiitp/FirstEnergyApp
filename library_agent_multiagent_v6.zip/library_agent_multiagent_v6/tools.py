"""
Tools the agent can call:

1. retrieve_policy   -> RAG lookup over the embedded policy documents (semantic,
                        for context/explanation).
2. check_loan_rule   -> deterministic check against the loan_rules table (an
                        in-memory SQLite database via SQLAlchemy, seeded from
                        data/rules.json), the "system input" rules the agent
                        must obey exactly.
3. check_catalog     -> looks up a book's category and copy availability from
                        the books table (same in-memory database, seeded from
                        data/catalog.json).

Rules are enforced by (2), a plain Python function backed by a real database
query -- the LLM is not trusted to do the arithmetic/limits itself, it calls
this tool and reports the result. RAG (1) is used for anything that needs the
*wording*/reasoning behind a rule (fines, reservations, renewals) rather than
a hard numeric check.

See db.py for the SQLAlchemy models, in-memory database setup, and seeding
logic. This module only calls the query helpers it exposes -- it never talks
to the database directly.
"""

import os

from langchain_core.tools import tool
from langchain_community.vectorstores import FAISS
from langchain_huggingface import HuggingFaceEmbeddings

from db import (
    init_db,
    get_book,
    get_loan_rule,
    get_valid_membership_types,
    rare_special_requires_approval,
    get_rules_dict,
)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
INDEX_DIR = os.path.join(BASE_DIR, "data", "faiss_index")

# Creates the in-memory SQLite tables (if not already created) and seeds them
# from data/catalog.json + data/rules.json. Safe to call more than once.
init_db()

# Kept for agent.py's Supervisor system prompt, which still expects a plain
# dict it can json.dumps() for context -- now reconstructed from the database
# instead of being read directly from rules.json.
RULES = get_rules_dict()

_embeddings = None
_vectorstore = None


def _get_vectorstore():
    global _embeddings, _vectorstore
    if _vectorstore is None:
        if not os.path.isdir(INDEX_DIR):
            raise RuntimeError(
                "FAISS index not found. Run `python build_vectorstore.py` first."
            )
        _embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
        _vectorstore = FAISS.load_local(
            INDEX_DIR, _embeddings, allow_dangerous_deserialization=True
        )
    return _vectorstore


@tool
def retrieve_policy(query: str) -> str:
    """Semantic search over the library's policy documents (lending, fines,
    reservations, membership). Use this to explain *why* a rule exists, or to
    answer questions not covered by the numeric rule checker, e.g. fine
    amounts, renewal conditions, reservation queueing."""
    vs = _get_vectorstore()
    results = vs.similarity_search(query, k=3)
    if not results:
        return "No relevant policy found."
    return "\n---\n".join(f"[{r.metadata.get('source')}] {r.page_content}" for r in results)


@tool
def check_loan_rule(membership_type: str, book_category: str, requested_days: int) -> str:
    """Deterministically check a loan request against the library's system
    rules (the loan_rules table, an in-memory database seeded from
    data/rules.json). membership_type must be one of Student, Faculty,
    Guest. book_category must be one of General, Reserve, Reference,
    RareSpecial. requested_days is the number of days the member wants to
    borrow the book for. Returns whether the request is allowed, and if not,
    the maximum allowed loan period."""
    mt = membership_type.strip().title()
    cat = book_category.strip()

    if mt not in get_valid_membership_types():
        return f"Unknown membership_type '{membership_type}'. Must be Student, Faculty, or Guest."

    max_days = get_loan_rule(mt, cat)
    if max_days is None:
        return f"Unknown book_category '{book_category}'. Must be General, Reserve, Reference, or RareSpecial."

    if max_days == 0:
        return (
            f"DENIED: {cat} books cannot be borrowed by {mt} members "
            f"(loan period is 0 for this category)."
        )

    if cat == "RareSpecial" and rare_special_requires_approval():
        approval_note = " NOTE: Rare/Special items require Head Librarian approval regardless of duration."
    else:
        approval_note = ""

    if requested_days <= max_days:
        return (
            f"APPROVED: {requested_days} day(s) is within the {max_days}-day maximum "
            f"for {mt}/{cat}.{approval_note}"
        )
    else:
        return (
            f"CAPPED: requested {requested_days} day(s) exceeds the {max_days}-day "
            f"maximum for {mt}/{cat}. Loan should be capped at {max_days} day(s), "
            f"and the member informed of the maximum.{approval_note}"
        )


@tool
def check_catalog(book_title: str) -> str:
    """Look up a book in the library catalog by title (case-insensitive).
    Returns its category and how many copies are currently available."""
    entry = get_book(book_title)
    if not entry:
        return f"'{book_title}' was not found in the catalog."
    return (
        f"Title: {entry['title']} | Category: {entry['category']} | "
        f"Available copies: {entry['available_copies']} / {entry['total_copies']}"
    )


TOOLS = [retrieve_policy, check_loan_rule, check_catalog]
