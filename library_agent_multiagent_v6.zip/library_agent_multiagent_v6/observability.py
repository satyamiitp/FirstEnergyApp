"""
Lightweight observability for the library multi-agent system.

Two complementary layers:

1. AgentTraceLogger (always on, zero external dependencies, zero setup) --
   a LangChain callback handler that prints a readable trace of every LLM
   call and every tool call to the console, with elapsed time for each.
   Attach the shared TRACE_LOGGER instance to every ChatOllama(...,
   callbacks=[TRACE_LOGGER]) in the app (agent.py, catalog_agent.py,
   rules_agent.py, policy_agent.py) and you'll see the full call chain for
   a single request -- Supervisor deciding to delegate, each specialist's
   own LLM call, each raw tool call (check_catalog, check_loan_rule,
   retrieve_policy) -- as it happens, without needing any external service
   or API key.

2. LangSmith (optional, zero code changes beyond environment variables) --
   if LANGSMITH_TRACING=true and LANGSMITH_API_KEY are set in the
   environment, LangChain automatically sends full traces (every LLM call,
   every tool call, timing, token usage, nested by agent) to
   smith.langchain.com, viewable in a web UI. This requires a (free)
   LangSmith account. See README for setup. langsmith_status() just prints
   whether this is currently active, so it's obvious at startup which mode
   you're running in.
"""

import logging
import os
import time

from langchain_core.callbacks import BaseCallbackHandler

logging.basicConfig(level=logging.INFO, format="%(message)s")
logger = logging.getLogger("library_agent.trace")


class AgentTraceLogger(BaseCallbackHandler):
    """Prints an indented, human-readable trace of LLM calls and tool calls
    as they happen, with elapsed time for each. Stateless across calls
    except for tracking in-flight start times, so one shared instance can
    safely be attached to every agent in the app."""

    def __init__(self):
        super().__init__()
        self._llm_start_times: dict = {}
        self._tool_start_times: dict = {}

    def on_chat_model_start(self, serialized, messages, *, run_id, **kwargs):
        self._llm_start_times[run_id] = time.monotonic()
        model = serialized.get("kwargs", {}).get("model", "unknown-model")
        logger.info(f"[LLM call]  -> {model}")

    def on_llm_end(self, response, *, run_id, **kwargs):
        started = self._llm_start_times.pop(run_id, time.monotonic())
        elapsed = time.monotonic() - started
        tool_calls = None
        try:
            message = response.generations[0][0].message
            tool_calls = getattr(message, "tool_calls", None)
        except (AttributeError, IndexError):
            pass
        if tool_calls:
            names = ", ".join(tc["name"] for tc in tool_calls)
            logger.info(f"[LLM done]  <- requested tool(s): {names}  ({elapsed:.1f}s)")
        else:
            logger.info(f"[LLM done]  <- final answer  ({elapsed:.1f}s)")

    def on_tool_start(self, serialized, input_str, *, run_id, **kwargs):
        self._tool_start_times[run_id] = time.monotonic()
        name = serialized.get("name", "unknown-tool")
        logger.info(f"  [tool call] {name}({input_str!r})")

    def on_tool_end(self, output, *, run_id, **kwargs):
        started = self._tool_start_times.pop(run_id, time.monotonic())
        elapsed = time.monotonic() - started
        text = str(output)
        preview = text if len(text) <= 120 else text[:120] + "..."
        logger.info(f"  [tool done] -> {preview}  ({elapsed:.1f}s)")


# Shared singleton -- import this into every file that builds a ChatOllama
# instance, rather than creating a new logger per agent.
TRACE_LOGGER = AgentTraceLogger()


def langsmith_status() -> str:
    """Human-readable note about whether LangSmith tracing is active,
    meant to be printed once at startup (main.py, api.py)."""
    enabled = (
        os.environ.get("LANGSMITH_TRACING", "").lower() == "true"
        or os.environ.get("LANGCHAIN_TRACING_V2", "").lower() == "true"
    )
    if enabled:
        project = os.environ.get("LANGSMITH_PROJECT", "default")
        return f"LangSmith tracing: ON (project='{project}')"
    return (
        "LangSmith tracing: OFF "
        "(set LANGSMITH_TRACING=true and LANGSMITH_API_KEY to enable; "
        "console trace logging is always on regardless)"
    )
