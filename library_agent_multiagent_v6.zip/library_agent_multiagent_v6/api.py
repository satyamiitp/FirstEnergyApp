"""
FastAPI wrapper around the library agent, so it can be called over HTTP
(e.g. from Postman) instead of only through the CLI (main.py).

Run:
    uvicorn api:app --reload --port 8000

Endpoints:
    GET  /health -> quick liveness check
    POST /ask    -> {"query": "...", "thread_id": "... (optional)"}
                 -> {"response": "...", "thread_id": "...", "structured": {...}}

Async: both endpoints are `async def`, and /ask calls the Supervisor with
`await _agent.ainvoke(...)` instead of the blocking `.invoke(...)`. This
lets uvicorn keep handling other requests while one multi-agent chain (up to
~7 sequential LLM calls, see the earlier trace) is still running, instead of
the whole server blocking on a single slow request.

Conversation memory: the Supervisor has a LangGraph checkpointer, keyed by
thread_id. If a request doesn't include one, a new thread_id is generated
and returned in the response -- pass that same thread_id back on your next
call to continue the same conversation (e.g. "okay, make it 10 days
instead" following up on a previous answer).

Structured output: the response includes a `structured` field (see
schemas.py's LoanResponse) alongside the plain-text `response`, so a real
client doesn't have to parse English sentences to know whether a loan was
approved, capped, or denied.
"""

import uuid
from contextlib import asynccontextmanager
from typing import Optional

from dotenv import load_dotenv

load_dotenv()

from fastapi import FastAPI
from pydantic import BaseModel

from agent import build_agent
from observability import langsmith_status
from schemas import LoanResponse

# Built once at startup (via the lifespan handler below), reused across requests.
_agent = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    global _agent
    _agent = build_agent()
    print(langsmith_status())
    yield
    # Nothing to tear down -- the agent and its in-memory checkpointer/DB
    # simply go away when the process exits.


app = FastAPI(title="Library Management Agent API", lifespan=lifespan)


class AskRequest(BaseModel):
    query: str
    thread_id: Optional[str] = None


class AskResponse(BaseModel):
    response: str
    thread_id: str
    structured: Optional[LoanResponse] = None


@app.get("/health")
async def health():
    return {"status": "ok", "agent_loaded": _agent is not None}


@app.post("/ask", response_model=AskResponse)
async def ask(request: AskRequest):
    thread_id = request.thread_id or str(uuid.uuid4())
    config = {"configurable": {"thread_id": thread_id}}

    result = await _agent.ainvoke(
        {"messages": [{"role": "user", "content": request.query}]},
        config=config,
    )

    structured = result.get("structured_response")
    if structured is not None:
        # With response_format set, the LAST message in result["messages"] is
        # actually a generic auto-generated acknowledgment (e.g. "Returning
        # structured response: ..."), not a friendly answer -- the real
        # human-readable text lives in structured_response.message instead.
        content = structured.message
    else:
        final_message = result["messages"][-1]
        content = getattr(final_message, "content", str(final_message))

    return AskResponse(response=content, thread_id=thread_id, structured=structured)
