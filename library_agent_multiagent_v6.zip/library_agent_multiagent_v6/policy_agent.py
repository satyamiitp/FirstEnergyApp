"""
Policy Agent -- one of the library's three specialist agents.

Its only job is RAG search over the policy markdown documents (fines,
renewals, reservations, membership). It wraps the single retrieve_policy
tool in a narrowly scoped LangChain tool-calling agent, then exposes that
whole agent to the Supervisor (agent.py) as one callable tool:
ask_policy_agent.
"""

import os

from langchain.agents import create_agent
from langchain_core.tools import tool
from langchain_ollama import ChatOllama

from observability import TRACE_LOGGER
from tools import retrieve_policy

OLLAMA_MODEL = os.environ.get("LIBRARY_AGENT_MODEL", "llama3.1:8b")

POLICY_AGENT_PROMPT = """You are the Policy Agent for a university library.

Your only job is to call retrieve_policy to search the library's policy
documents (lending, fines, reservations, membership) and explain the
relevant wording/reasoning in plain language. If nothing relevant comes
back, say so instead of inventing an answer."""


def build_policy_agent(model: str = None):
    """Returns a compiled, runnable LangGraph agent scoped to policy RAG."""
    llm = ChatOllama(model=model or OLLAMA_MODEL, temperature=0, callbacks=[TRACE_LOGGER])
    return create_agent(llm, tools=[retrieve_policy], system_prompt=POLICY_AGENT_PROMPT)


def _run_agent(agent, question: str) -> str:
    result = agent.invoke({"messages": [{"role": "user", "content": question}]})
    final_message = result["messages"][-1]
    return getattr(final_message, "content", str(final_message))


def make_policy_agent_tool(model: str = None):
    """Builds the Policy Agent once and wraps it as a @tool the Supervisor
    can call, passing a natural-language sub-question and getting back the
    Policy Agent's natural-language answer."""
    policy_agent = build_policy_agent(model)

    @tool
    def ask_policy_agent(question: str) -> str:
        """Delegate to the Policy Agent. Ask it to explain fines, renewals,
        reservations, or membership policy wording, e.g. 'What is the fine
        for a late Reserve book?'"""
        return _run_agent(policy_agent, question)

    return ask_policy_agent
